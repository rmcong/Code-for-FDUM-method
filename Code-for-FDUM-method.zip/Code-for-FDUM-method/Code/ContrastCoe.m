function final = ContrastCoe(dcp)
final =exp((-mean(mean(dcp)))/100);
end